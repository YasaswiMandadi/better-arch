import { Link, Navigate, useParams } from 'react-router-dom';
import InnerLayout from '../components/InnerLayout';
import Section from '../components/Section';
import SiteFooter from '../components/SiteFooter';
import { DB } from '../data/db';
import { getCollaborator, collaboratorSlugForGuest } from '../data/collaborators';

/**
 * One page per essay. There are no essays published yet (DB.essays is an
 * empty array until the console can author them), so in practice this
 * template currently redirects home for every slug, same as Project/Episode
 * already do for an id that doesn't exist. Nothing here is placeholder
 * content, it's the real template, simply waiting for its first row of data.
 */
export default function Essay() {
  const { slug } = useParams();
  const essays: any[] = DB.essays as any;
  const seasons: any[] = DB.seasons as any;
  const essay = essays.find((x) => x.slug === slug);
  if (!essay) return <Navigate to="/" replace />;

  const s = seasons.find((x) => x.slug === essay.season);
  const authorCollaborator = essay.author ? getCollaborator(collaboratorSlugForGuest(essay.author)) : undefined;

  const items = [{ num: '01', label: 'Essay', href: '#s01' }];

  return (
    <InnerLayout
      sideItems={items}
      sideKicker={s ? `${s.no} · ${s.title}` : 'Essay'}
      sideFoot={[
        { label: '← Home', to: '/' },
        ...(s ? [{ label: s.title, to: `/project/${s.slug}` }] : []),
        { label: 'Contact', to: '/contact' },
      ]}
    >
      <p className="font-head font-semibold text-[11px] tracking-[.2em] uppercase text-red mb-4.5">
        {s ? `${s.no} · ${s.title} · Essay` : 'Essay'}
      </p>
      <h1 className="font-head font-extrabold text-[clamp(2.4rem,7.5vw,4.4rem)] leading-[1.02] tracking-tight mb-4">{essay.title}</h1>
      <p className="font-head font-semibold text-[1.18rem] leading-[1.5] text-muted max-w-[56ch]">
        {essay.author ? (
          authorCollaborator ? (
            <>By <Link to={`/collaborator/${authorCollaborator.slug}`} className="underline">{essay.author}</Link></>
          ) : (
            <>By {essay.author}</>
          )
        ) : null}
        {essay.sub ? ` · ${essay.sub}` : ''}
      </p>

      <Section ac="ac4" num="01" title="Essay">
        <div className="read space-y-4">
          {essay.body.map((p: string, i: number) => <p key={i}>{p}</p>)}
        </div>
      </Section>

      <SiteFooter />
    </InnerLayout>
  );
}
